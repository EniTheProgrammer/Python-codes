# Day 2:4 months of Python Basic Programming
Firstname="Eniola"
Lastname="Adigun"
Fullname="Eniola Adigun"
Country="Scotland"
City="Aberdeen"
Age=14
Year=2009
is_married="No"
is_true="Yes"
is_light_on="Yes"

"Firstname", "Lastname", "Fullname", "Country", "City", "Age", "Year", "is_married", "is_true", "is_light_on"